<?php
$conn = mysqli_connect("localhost","root","","inventory");
if (!$conn) {
  echo "connection not connected";
}
  include("include/header.php");
  if (!empty($_POST['search'])) {
    $search = $_POST['search'];
    $sql = "SELECT item_id,item_name,item_price,item_date,firstname from item, employee where item.emp_id=employee.emp_id AND CONCAT(item_name,item_price,item_date,firstname) LIKE'%$search%'";

    mysqli_set_charset($conn,"utf8");
    $result= mysqli_query($conn,$sql);

  }else{

    $sql = "SELECT item_id , item_name,item_price,item_date, firstname from item, employee WHERE item.emp_id = employee.emp_id";
    mysqli_set_charset($conn,"utf8");
    $result = mysqli_query($conn,$sql);

  }

 ?>
</br>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <!-- Latest compiled and minified CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="boot/css/bootstrap.min.css">
<link rel="stylesheet" href="boot/css/myCss.css">
<!-- jQuery library -->
<script src="boot/js/jquery.min.js"></script>

<!-- Popper JS -->
<script src="boot/js/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<style type="text/css">
  
  table.table{background-color: #fff;border: 1px solid black;}

</style>
  </head>
  <body>
      <div class="row">
          <div class="col-md-4" id="menu">
            <ul class="nav nav-pills">
                      <li role="presentation" class="active"><a href="index.php">برگشت</a>

            </ul>
          </div>

          <div class="col-md-6" id="fsearch">
            <form class="form-inline" action="" method="post">
              <div class="form-group">
               
              </div>
            </form>
          </div>
          <div class="col-md-2">
            <h2 class="header2">ریپورت اجناس </h2>
          </div>
        </div>
        <div class="row">
        <br/>
            <div class="col-md-12" id="content">
              <table class="table table-striped">
                      <thead>
                      <tr>
                        <th>نام جنس</th>
                        <th>قیمت</th>
                        <th>تاریخ</th>
                        <th>کارمندان</th>

                      </tr>
                    </thead>
                    <tbody>
                      <form method="get">
                      <?php

                          if(mysqli_num_rows($result)>0){
                            while ($row = mysqli_fetch_row($result)) {
                              echo "<tr>";
                                echo "<td>".$row[1]."</td>";
                                echo "<td>".$row[2]."</td>";
                                echo "<td>".$row[3]."</td>";
                                echo "<td>".$row[4]."</td>";




                              echo "</tr>";
                            }
                          }


                       ?>
                      </form>
                    </tbody>
              </table>

            </div>
          </div>
      </div>

    </div>
  </div>

  </body>
</html>
